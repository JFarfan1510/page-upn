<div class="wp-block-create-block-hola-mundo">
    <h2 >QUEREMOS CONOCERTE:</h2>
    <form action="" method="post" class="form-group"> 
        <label for="nombre" >Nombre *</label>
        <input type="text" name="nombre" maxlength="50" placeholder="Ejemplo:Luis Carlos" class="form-control" required><br>
        <label for="apellidos">Apellidos *</label>
        <input type="apellidos" name="apellidos" placeholder="Ejemplo:Ruiz Hernández" class="form-control" required><br>
        <label for="campus">Campus *</label>
        <select name="campus" class="form-control">
        <option value="0">Elige un campus de la lista</option>
            <?php foreach($campus as $value): ?>
                <option value="<?php echo $value ?>"> <?php echo $value ?></option>
            <?php endforeach?> 
        </select> <br>
        <label for="estudios">Nivel de estudios *</label>
        <select name="estudios" class="form-control" >
        <option value="0">Elige tu nivel de la lista</option>
            <?php foreach($estudios as $value): ?>
                <option value="<?php echo $value ?>"> <?php echo $value ?></option>
            <?php endforeach?> 
        </select> <br>
        <p>(*) campos obligatorios</p>
        <div class="btn-group mt-3">
            <button class="btn" type="submit"><a href="https://localhost/prueba_bloque/wordpress/?page_id=15">Siguiente</a></button>
            
        </div>
    </form>
</div>
</div>
</html>
