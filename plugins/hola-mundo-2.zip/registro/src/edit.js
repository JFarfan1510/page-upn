/**
 * Retrieves the translation of text.
 *
 * @see https://developer.wordpress.org/block-editor/packages/packages-i18n/
 */
import { __ } from '@wordpress/i18n';

/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/packages/packages-block-editor/#useBlockProps
 */
import { InspectorControls,RichText,useBlockProps } from '@wordpress/block-editor';

/**
 * Lets webpack process CSS, SASS or SCSS files referenced in JavaScript files.
 * Those files can contain any CSS code that gets applied to the editor.
 *
 * @see https://www.npmjs.com/package/@wordpress/scripts#using-css
 */
import './editor.scss';

/**
 * The edit function describes the structure of your block in the context of the
 * editor. This represents what the editor will render when the block is used.
 *
 * @see https://developer.wordpress.org/block-editor/developers/block-api/block-edit-save/#edit
 *
 * @return {WPElement} Element to render.
 */
import {Panel,PanelBody,TextControl} from "@wordpress/components";
const Edit = (props) => {
	const{attributes,setAttributes} = props;
	const{title,nameLabel,apellidoLabel,campusLabel,estudiosLabel} = attributes;
	return (
	<>
	<InspectorControls>
		<Panel>
			<PanelBody title='Labels' initialOpen={true}>
				<TextControl
					label = "Nombre Label"
					value = {nameLabel}
					onChange={(newLabel) => setAttributes({nameLabel:newLabel})}
				/>
				<TextControl
					label = "Apellido Label"
					value = {apellidoLabel}
					onChange={(newLabelA) => setAttributes({apellidoLabel:newLabelA})}
				/>
				<TextControl
					label = "Campus Label"
					value = {campusLabel}
					onChange={(newLabelA) => setAttributes({campusLabel:newLabelA})}
				/>
				<TextControl
					label = "Nivel de Estudios Label"
					value = {estudiosLabel}
					onChange={(newLabelA) => setAttributes({estudiosLabel:newLabelA})}
				/>
			</PanelBody>
		</Panel>
	</InspectorControls>
	<div class="signin">
        <div class="signin__container">
            <form class="signin__form" id="registro">
					<h1 class='sigin__titulo'>ESTÁS A NADA DE CAMBIAR TU FUTURO</h1>
					<p>Completa el siguiente formulario y te contactarémos al instante:</p>
					<div class="name--campo ">
        				<input type="text" name="nombre" maxlength="50" placeholder="Nombres" required/>
        				<input type="text" name="apellidoP" placeholder="Apellido Paterno" required/>
                	</div>
                	<div class="name--campo">
        				<input type="text" name="apellidoM" placeholder="Apellido Materno"  required/>
						<input type="text" name="correo" placeholder="Correo"  required/>
                	</div>
					<div class="name--campo">
        				<input type="text" name="celular" placeholder="Celular"  required/>
						<input type="text" name="colegio" placeholder="colegio de procedencia"  required/>
                	</div>
                <div class="name--campo">
					<select name="carrera" >
        				<option value="0">Carreras de interés</option>
						<option value="1">Lima Sur</option> 
						<option value="2">Lima Norte</option>
						<option value="3">Lima Centro</option> 
        			</select>
        			<select name="campus" >
        				<option value="0">Campus de interés</option>
						<option value="1">Lima Sur</option> 
						<option value="2">Lima Norte</option>
						<option value="3">Lima Centro</option> 
        			</select>
                </div>
				<div class="check">
					<input type="checkbox"/>
					<p>Acepto los términos y condiciones</p>
				</div>
                <div class="signin__submit">
                    <input type="submit" value="RESOLVER TEST DE ORIENTACIÓN"/>
                </div>
                <div class="msg"></div>
            </form>
			<div class="sing__img">
				<h2>VIDEO TUTORIAL</h2>
				<p>¿No sabes cómo resolver tu test? Aquí te lo explicamos:</p>
				<img src="./group-8.png" alt="Logo" />
			</div>
        </div>
    </div>
	</>
	);
}

export default Edit;
