<?php

function test_registro_render_callback($block_attributes,$block_content){
    ob_start();
    require __DIR__ . '/registro.tpl.php';
	return ob_get_clean();
}
add_action( 'init', 'test_registro_blocks' );
function test_registro_blocks() {
    $assets_file = include_once PLZ_PATH . "/registro/build/index.asset.php";

    wp_register_script(
        'test-registro-block',
        plugins_url('./build/index.js', __FILE__),
        $assets_file['dependencies'],
        $assets_file['version']
    );

    wp_register_style(
        'test-registro-block',
        plugins_url('./build/index.css', __FILE__),
        array(),
        $assets_file['version']
    );
	register_block_type(
        __DIR__,
        array(
            'render_callback' => 'test_registro_render_callback',
        ) 
        //'test/registro',
        //array(
        //    'editor_script' => 'test-registro-block',
       //     'style'         => 'test-registro-block'
        //)
    );
}