<div class="signin">
        <div class="signin__container">
            <form class="signin__form" id="registro">
					<h1 class='sigin__titulo'>ESTÁS A NADA DE CAMBIAR TU FUTURO</h1>
					<p>Completa el siguiente formulario y te contactarémos al instante:</p>
					<div class="name--campo ">
        				<input type="text" name="nombre" maxlength="50" placeholder="Nombres" required/>
        				<input type="text" name="apellidoP" placeholder="Apellido Paterno" required/>
                	</div>
                	<div class="name--campo">
        				<input type="text" name="apellidoM" placeholder="Apellido Materno"  required/>
						<input type="text" name="correo" placeholder="Correo"  required/>
                	</div>
					<div class="name--campo">
        				<input type="text" name="celular" placeholder="Celular"  required/>
						<input type="text" name="colegio" placeholder="colegio de procedencia"  required/>
                	</div>
                <div class="name--campo">
					<select name="carrera" >
        				<option value="0">Carreras de interés</option>
						<option value="1">Lima Sur</option> 
						<option value="2">Lima Norte</option>
						<option value="3">Lima Centro</option> 
        			</select>
        			<select name="campus" >
        				<option value="0">Campus de interés</option>
						<option value="1">Lima Sur</option> 
						<option value="2">Lima Norte</option>
						<option value="3">Lima Centro</option> 
        			</select>
                </div>
				<div class="check">
					<input type="checkbox"/>
					<p>Acepto los términos y condiciones</p>
				</div>
                <div class="signin__submit">
                    <input type="submit" value="RESOLVER TEST DE ORIENTACIÓN"/>
                </div>
                <div class="msg"></div>
            </form>
			<div class="sing__img">
				<h2>VIDEO TUTORIAL</h2>
				<p>¿No sabes cómo resolver tu test? Aquí te lo explicamos:</p>
				<img src="./group-8.png" alt="Logo" />
			</div>
        </div>
    </div>