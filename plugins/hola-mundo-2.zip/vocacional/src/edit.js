import {useBlockProps,InspectorControls} from "@wordpress/block-editor";
import apiFetch from "@wordpress/api-fetch";
import {useState,useEffect} from "@wordpress/element";
import {Panel,PanelBody,SelectControl} from "@wordpress/components"


const Edit = (props) => {
    let test_id = props.test;
    let data = [];
    let test_contador = 0;
    let test_number = 1;
    let test_data = /* fetch(test_id) */[
        {
            'pregunta': '¿Cuanto es 1+1?',
            'respuestas': [
                '1',
                '2',
                '3',
            ],
            'correct':'2'
        },
        {
            'pregunta': '¿De qué color es el cielo?',
            'respuestas': [
                'azul',
                'negro',
                'amarillo',
            ],
            'correct':'azul'
        },
        {
            'pregunta': '¿Cuanto es 3x3?',
            'respuestas': [
                '6',
                '8',
                '9',
            ],
            'correct':'9'
        }
    ];
    //const {currentPage,SetCurrentPage} = useState(0);

    const filteredData = test_data.slice(0,0 + 1);
    //const nextPage = SetCurrentPage(currentPage + 1);

    return (
        <>
        <div className="barra">
            <div className="bar"></div>
        </div>
        {
            filteredData.map(item => (
                    <div className=''>
                        <div className='section'>
                            <h4><span>Pregunta {test_number++}: </span>{item.pregunta}</h4>
                            {
                                item.respuestas.map(rpta => (

                                    <div className='respuestas'>
                                        <p><input type="radio" name="rpta" value={rpta}></input> {rpta}</p>
                                    </div>
                                ))
                            }
                        </div>
                    </div>
            ))

        }
            <div className="btn">
                <button className='btn-enviar' >Siguiente</button>
            </div>
        </>
    );
};

export default Edit;

