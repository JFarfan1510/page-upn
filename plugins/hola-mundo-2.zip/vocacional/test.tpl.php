<?php use function htmlspecialchars as e; ?>

<form id="test-vocacional" action="#">
	<div class="progreso">
		<div class="progreso-porcentaje">Progreso: <span>0%</span></div>
		<div class="progreso-time">Tiempo: <span>0h 0m 0s</span></div>
		<div class="progreso-barra"><span></span></div>
	</div>

	<?php foreach ($data as $pregunta_id => $pregunta) { ?>
	<div class="pregunta">
		<h4 class="pregunta-texto">
			<?=e($pregunta['texto'])?>
		</h4>
		<ul>
			<?php foreach ($pregunta['alternativas'] as $alternativa_id => $alternativa) { ?>
			<li class="alternativa">
				<label>
					<input type="radio" name="pregunta-<?=$pregunta_id?>" value=<?=$alternativa_id?>> <?=$alternativa['texto']?>
				</label>
			</li>
			<?php } ?>
		</ul>
	</div>
	<?php } ?>

	<div class="notice"></div>

	<div class="buttons">
		<button type="button" class="previous">Anterior</button>
		<button type="submit" class="next">Siguiente</button>
		<button type="button" class="finish">Finalizar</button>
	</div>
</form>
