<?php

function test_vocacional_obtener_data () {
	$data = json_decode(file_get_contents(__DIR__ . '/test-vocacional-preguntas-1.json'), true);
	return $data;
}

function test_vocacional_render_callback ($block_attributes, $block_content){
	// obtener data
	$data = test_vocacional_obtener_data();

	// renderizar
	ob_start();
	require __DIR__ . '/test.tpl.php';
	return ob_get_clean();
}

add_action('init', function (){
	wp_register_script(
		'test-vocacional',
		plugins_url('./main.js', __FILE__ )
	);

	register_block_type(
		__DIR__,
		[
			'render_callback' => 'test_vocacional_render_callback',
			'script'          => 'test-vocacional'
		]
	);
});
