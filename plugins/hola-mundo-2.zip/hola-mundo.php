<?php
/**
 * Plugin Name:       Test
 * Description:       Example block written with ESNext standard and JSX support – build step required.
 * Requires at least: 5.8
 * Requires PHP:      7.0
 * Version:           0.1.0
 * Author:            Saduj Chavez
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       hola-mundo
 *
 * @package           create-block
 */

/**
 * Registers the block using the metadata loaded from the `block.json` file.
 * Behind the scenes, it registers also all assets so they can be enqueued
 * through the block editor in the corresponding context.
 *
 * @see https://developer.wordpress.org/reference/functions/register_block_type/
 */

define("PLZ_PATH",plugin_dir_path(__FILE__));


//blocks
// require_once PLZ_PATH . '/registro/index.php';
require_once PLZ_PATH . '/vocacional/index.php';

// function test_plugin_activar(){
// 	add_roles('cliente',"Cliente","read_post");
// }
